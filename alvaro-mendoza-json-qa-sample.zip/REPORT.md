# Synthetic JSON localization QA sample

Prepared by Álvaro Mendoza | alvaromendoza.work@gmail.com

This is a self-created demonstration. It is not previous client work.

## Scope

Six English source strings, two target JSON files. Checks: missing/extra keys, blank values, simple placeholders and literal HTML tag differences. Production uses code and AI.

## Before and after

| File | Findings before | Findings after proposed correction |
| --- | ---: | ---: |
| Spanish | 5 | 0 |
| Catalan comparison | 0 | No correction proposed |

## Findings and proposed corrections

| Key | Finding | Proposal |
| --- | --- | --- |
| /checkout/greeting | Variable changed from {name} to {nombre} | Preserve {name} |
| /checkout/pay | Empty string | Pagar ahora |
| /checkout/help | Source strong tags missing | Restore the source tag pair around the translated phrase |
| /checkout/total | Key missing | Total: {amount} |
| /checkout/legacy | Extra key | Removed only in this synthetic example; real projects need a code-usage check before deletion |

## Reproduce

Requires Node.js with ES modules and structuredClone support. Run from the sample pack folder:

```
node qa-localitzacio.mjs en.json es.json ca.json
node qa-localitzacio.mjs en.json es-proposta.json
```

Original input files were not modified. The manifest lists SHA-256 hashes for the sample artifacts.

## Limits

Zero findings means only that these checks passed. It does not establish translation accuracy, correct application behavior, ICU/plural correctness, HTML validity or correct tag nesting. Duplicate JSON object keys are not detected. Supported inputs contain only nested strings, objects or arrays of those. The placeholder detector handles simple brace, Mustache, printf and colon forms; custom syntax needs an agreed adapter. Literal HTML comparison may flag valid attribute localization for review.
