# Gumroad to Airtable — reproducible local sample

Prepared by Álvaro Mendoza. Production uses code and AI.
This is a synthetic demonstration, not previous client work or a live deployment.

## Run locally

Requires a current Node.js version with the built-in node:test runner.
No package installation or account credentials are required.

```
node --test prototip.test.mjs
node prototip.mjs
```

The CLI uses an in-memory mock only. It makes no live API requests. The exported
adapter functions require an explicit fetch implementation if integrated elsewhere.
Do not supply production credentials or connect live accounts for this sample.

## What is demonstrated

Field mapping and validation; preservation of amounts in minor units and currency;
paginated collection with repeated-page detection; deduplication by sale ID;
ten-record upsert batches; bounded rate-limit/server-error retries; explicit errors
for invalid inputs and incomplete responses. Nine tests use simulated APIs.
The CLI replays three sale events containing two IDs twice, retaining two mock rows.

## Limits and work before deployment

No scheduler, persistent recovery log, concurrent-run protection or live integration
validation is included. A write can have an unknown or partial outcome: reconciliation
is required before claiming a complete sync. A recent-sales window alone will not
necessarily detect refunds or changes to old sales. Confirm actual schema, API access,
volume, permissions and retry policy against current vendor documentation before deployment.
The basic field/date checks are not a complete business-data schema validator.

Any paid scope, acceptance criteria, permitted tools and payment terms require a
separate agreement. This package contains no quote or commercial commitment.
